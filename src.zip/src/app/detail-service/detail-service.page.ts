import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detail-service',
  templateUrl: './detail-service.page.html',
  styleUrls: ['./detail-service.page.scss'],
})
export class DetailServicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
