import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createnew',
  templateUrl: './createnew.page.html',
  styleUrls: ['./createnew.page.scss'],
})
export class CreatenewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
