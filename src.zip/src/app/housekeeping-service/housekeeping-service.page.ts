import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-housekeeping-service',
  templateUrl: './housekeeping-service.page.html',
  styleUrls: ['./housekeeping-service.page.scss'],
})
export class HousekeepingServicePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
